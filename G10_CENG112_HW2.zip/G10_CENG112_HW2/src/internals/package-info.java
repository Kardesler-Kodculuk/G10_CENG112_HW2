/**
* A package that includes some basic containers, Queues and Stacks.
*/

package internals;