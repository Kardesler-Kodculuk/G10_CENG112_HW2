/**
 * Includes the parts to be produced.
 */
package parts;