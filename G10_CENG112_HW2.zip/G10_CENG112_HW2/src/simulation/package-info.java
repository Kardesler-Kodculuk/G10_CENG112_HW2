/**
 * Includes simulation parts, such as the MarketAnalyst
 * Storage chief etc.
 */
package simulation;